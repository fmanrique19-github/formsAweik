import { InputNameDirective } from './input-name.directive';

describe('InputNameDirective', () => {
  it('should create an instance', () => {
    const directive = new InputNameDirective();
    expect(directive).toBeTruthy();
  });
});
