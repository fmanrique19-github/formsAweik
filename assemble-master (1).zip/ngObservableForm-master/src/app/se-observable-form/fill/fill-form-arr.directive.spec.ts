import { FillFormArrDirective } from './fill-form-arr.directive';

describe('FillFormArrDirective', () => {
  it('should create an instance', () => {
    const directive = new FillFormArrDirective();
    expect(directive).toBeTruthy();
  });
});
