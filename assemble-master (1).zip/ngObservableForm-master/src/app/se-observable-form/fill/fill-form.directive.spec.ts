import { FillFormDirective } from './fill-form.directive';

describe('FillFormDirective', () => {
  it('should create an instance', () => {
    const directive = new FillFormDirective();
    expect(directive).toBeTruthy();
  });
});
