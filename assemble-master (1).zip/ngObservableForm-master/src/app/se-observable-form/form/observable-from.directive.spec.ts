import { ObservableFormDirective } from './observable-form.directive';

describe('ObservableFromDirective', () => {
  it('should create an instance', () => {
    const directive = new ObservableFormDirective();
    expect(directive).toBeTruthy();
  });
});
