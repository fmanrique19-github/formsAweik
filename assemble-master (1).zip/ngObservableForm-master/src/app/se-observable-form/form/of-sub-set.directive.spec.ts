import { OfSubSetDirective } from './of-sub-set.directive';

describe('OfSubSetDirective', () => {
  it('should create an instance', () => {
    const directive = new OfSubSetDirective();
    expect(directive).toBeTruthy();
  });
});
