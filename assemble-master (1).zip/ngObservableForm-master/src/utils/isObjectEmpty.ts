export const isEmptyObject = (o: object) => Object.keys(o).length === 0;
