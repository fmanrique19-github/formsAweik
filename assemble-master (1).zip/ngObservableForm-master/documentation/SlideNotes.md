# Notes for 'The form awakens` @ ngConf 2019

| #   | remark                                                 |
| --- | ------------------------------------------------------ |
| 1   | Space, the final... galaxy in its observable form      |
| 2   | The form awakens, highlight my journey,                |
| 3   | About me                                               |
| 4   | Tell about assignment, mention changes only ,demo form |
| 5   | Template driven form, not so bad..                     |
| 6   | Just add those BiB's                                   |
| 7   | Make a clone, extract the changes                      |
| 8   | 10 repetitions, typos, keys macro, better TTT          |
| 9   | (yeah, quotes), Template looks better, small font      |
| 10  | Have to add this formcontrolls,                        |
| 11  | and those magix strings. no typos. 3x propname         |
| 12  | no manual clone, still have to extract the changes     |
| 13  | cloning, manual work, creating formgroups, nesting     |
| 14  | avoid DI, aid perf, changes only,native elm, attr      |
| 15  | Unrevealed, BF, DRY, noclone nothing?                  |
| 16  | html5                                                  |
| 17  | demoform, show changes, show reset                     |
|     | complex, show nested data, show template               |
| 19  | looking for contributors, work out validation model    |
| 20  | thanks! github                                         |
